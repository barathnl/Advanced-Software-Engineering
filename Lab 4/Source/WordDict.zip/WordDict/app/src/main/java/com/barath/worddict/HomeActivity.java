package com.barath.worddict;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class HomeActivity extends AppCompatActivity {

    TextView outputTextView1,outputTextView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        outputTextView1 = (TextView) findViewById(R.id.search_result);
        outputTextView2 = (TextView) findViewById(R.id.meaning);
    }
    public void logout(View v) {
        Intent redirect = new Intent(HomeActivity.this, MainActivity.class);
        startActivity(redirect);
    }
    String wordkey;
    public void checkMeaning(View v){
        TextView word = (TextView) findViewById(R.id.searchText);
        wordkey = word.getText().toString();
        final String WIFI = "Wi-Fi";
        final String ANY = "Any";
        String geturl="http://api.pearson.com/v2/dictionaries/entries?search="+wordkey+"&limit=1";
        Log.i("url is...",geturl);
        final String response1 = "";
        OkHttpClient client = new OkHttpClient();
        try{
            Request request = new Request.Builder()
                    .url(geturl)
                    .build();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    System.out.println(e.getMessage());
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    final JSONObject jsonResult;
                    final String result = response.body().string();
                    try {
                        jsonResult = new JSONObject(result);
                        JSONArray result1 = jsonResult.getJSONArray("results");
                        JSONObject result2 = result1.getJSONObject(0);
                        final String r1="Part of speech : "+result2.getString("part_of_speech");
                        final String r2;
                        JSONArray result3 = result2.getJSONArray("senses");
                        Log.d("Sense", result3.toString());
                        JSONObject result4 = result3.getJSONObject(0);
                        r2="Meaning : "+result4.getString("definition");
                        Log.d("Part_of_speech", r1.toString());
                        Log.d("Meaning is...", r2.toString());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                outputTextView1.setText(r1);
                                outputTextView2.setText(r2);
                            }
                        });

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (Exception ex){

        }
    }
}
